# limetext configuration
export PKG_CONFIG_PATH=$GOPATH/src/github.com/limetext/rubex
alias limeqml="(cd $GOPATH/src/github.com/limetext/lime-qml/main && go build && ./main)"
