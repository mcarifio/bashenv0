# installed in an odd location
# update directions, etc. https://emscripten.org/docs/getting_started/Tutorial.html
# Note: if you move the installation directory, `/opt/emsdk/emsdk-gh/emsdk activate latest` and then source emsdk_env.sh again.
#  (b/c ~/.emscripten hardcodes paths, gross)
source_if_exists /opt/emsdk/current/bin/emsdk_env.sh &> /dev/null

