# sourced by /etc/profile
# test with: . /etc/profile.d/play.sh

alias play=/opt/play/current/play

