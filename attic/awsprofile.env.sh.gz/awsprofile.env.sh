function awsprofile {
  local profile=${1:?'need a profile'}
  for k in aws_access_key_id aws_secret_access_key; do
    export ${k^^}=$(aws configure --profile=${profile} get ${k})
  done
}
