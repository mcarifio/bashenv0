export SCONSFLAGS='-Q'
