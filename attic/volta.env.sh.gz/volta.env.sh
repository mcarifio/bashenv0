u.have.command volta || return 0
source <(volta completions $(me.name))

# tabtab source for serverless package
# uninstall by removing these lines or running `tabtab uninstall serverless`
u.source ${VOLTA_HOME}/tools/image/packages/serverless/1.52.2/node_modules/tabtab/.completions/serverless.bash

