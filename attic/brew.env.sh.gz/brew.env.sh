eval "$(/home/linuxbrew/.linuxbrew/bin/brew shellenv)"
