# is hub https://hub.github.com/ installed?
have-command hub && eval "$(hub alias -s)"
