# Add gem directory to path
[[ -x /usr/bin/gem ]] && export PATH=$(/usr/bin/gem environment gemdir 2>/dev/null)/bin:$PATH

