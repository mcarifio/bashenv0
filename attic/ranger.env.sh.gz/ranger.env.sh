# Mike Carifio <mike@carif.io>
export RANGER_LOAD_DEFAULT_RC=FALSE
