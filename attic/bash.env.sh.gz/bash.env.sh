# https://www.gnu.org/software/bash/manual/html_node/The-Shopt-Builtin.html
shopt -s extdebug # declare -F ${name} => ${name} ${lineno} ${pathname}
# shopt -s nullglob # http://bash.cumulonim.biz/NullGlob.html nullglob
shopt -s globstar
shopt -s failglob
shopt -s autocd cdable_vars
shopt -s checkhash
shopt -s no_empty_cmd_completion

