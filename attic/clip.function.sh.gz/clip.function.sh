clip() {
    xclip -selection c "${1}" # add more flags like -verbose
}
