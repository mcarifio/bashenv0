# perl6 rakudo
# eval $(~/.rakudobrew/bin/rakudobrew init -)

