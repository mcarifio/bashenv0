# https://docs.perl6.org/language/unicode_entry
input_module=xim
export GTK_IM_MODULE=$input_module
export XMODIFIERS=@im=$input_module
export QT_IM_MODULE=$input_module
