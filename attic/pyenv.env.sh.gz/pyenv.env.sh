# Load pyenv automatically by adding
# the following to ~/.bash_profile:

eval "$(direnv hook bash)"

path_if_exists ${HOME}/.pyenv/bin
eval "$(pyenv init -)"
eval "$(pyenv virtualenv-init -)"
