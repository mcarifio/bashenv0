path_if_exists /snap/bin # probably already there

