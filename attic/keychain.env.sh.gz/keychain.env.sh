# TODO mcarifio: fix keychain and contents of ~/.ssh/keys.d; coordinate with sawfish
# Both public and private keys must be available.
# To recover the .pub from the private key: ssh-keygen -y -f ${private_filename} > ${private_filename}.pub
# eval "$(keychain --quiet --quick --ignore-missing --eval  id_rsa ~/.ssh/keys.d/${USER}-*-all.pem)"

# remove these when everything works
# keychain -q ~/.ssh/id_rsa
# keychain --confhost ~/.ssh/id_rsa
# . ~/.keychain/$HOSTNAME-sh

# Add keys here
# ssh-add ~/.ssh/keys/mcarifio-encirca-all.pem
# ssh-add ~/.ssh/keys/kayako_encirca.pem
