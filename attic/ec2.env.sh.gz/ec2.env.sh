# http://docs.aws.amazon.com/cli/latest/userguide/cli-chap-getting-started.html
# deprecated in favor of ~/.aws/credentials

# http://docs.aws.amazon.com/AWSEC2/latest/CommandLineReference/set-up-ec2-cli-linux.html
#export AWS_ACCOUNT_ID=444619505703
#export AWS_ACOUNT_NAME=mcarifio
#export AWS_ACCESS_KEY=AKIAJNBKWTU3TTAS6WPA
#export AWS_SECRET_KEY=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

