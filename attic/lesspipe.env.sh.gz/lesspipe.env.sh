# less pipe can look inside archives
export LESSOPEN="|lesspipe %s"
export LESS='-R'
