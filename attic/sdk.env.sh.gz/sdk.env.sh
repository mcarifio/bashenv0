# https://sdkman.io/
source_if_exists ~/.sdkman/bin/sdkman-init.sh
