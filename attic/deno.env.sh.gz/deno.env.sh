path_if_exists ~/.deno/bin

