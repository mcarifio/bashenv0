if [[ -z "${ASDF_BIN}" ]] ; then
   source $(dirname ${BASH_SOURCE})/asdf.env.sh
fi

export onepassword_email='mike@carif.io'
export onepassword_password='!!Bl0w!!m33!!'
export onepassword_secret_key='A3-HG4HJY-Q9CQX3-SYRMG-G2QMJ-F3CCP-N7RME'
export onepassword_url='https://my.1password.com/'
# first time
# echo "${onepassword_password}" | op signin "${onepasssword_url}" "${onepassword_email}" "${onepassword_secret_key}" --output=raw

eval $(op signin my <<< "${onepassword_password}") 
