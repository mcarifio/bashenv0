# http://emacs-fu.blogspot.com/2009/02/emacs-daemon.html
#alias ec="emacsclient -a '' -n -c"
alias ec="emacsclient -a '' -n "