# export RUST_SRC_PATH=$HOME/src/rust/src
# [[ -d ${RUST_SRC_PATH} ]] || echo "expecting a directory at RUST_SRC_PATH (${RUST_SRC_PATH}), none found. $(type -p racer) won't work"

path_if_exists ~/.cargo/bin

