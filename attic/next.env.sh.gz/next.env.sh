function next() {
  env GDK_SCALE=2 GDK_DPI_SCALE=0.5 /usr/local/bin/next $*
}
