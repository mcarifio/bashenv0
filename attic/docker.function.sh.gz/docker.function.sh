# http://lucapette.me/docker/a-couple-of-useful-aliases-for-docker/

function is_command {
    type -p $1 2>&-
}

function docker {
  # set -x -- bashdb doesn't work
  if is_command "docker-$1" ; then
    local subcommand=$1; shift
    sudo $(type -p docker-${subcommand}) $@
  else
    sudo \docker $@
  fi
  # set +x
}
