# if rvm installed source the config file
[[ -r ~/.rvm/scripts/rvm ]] && source /home/mcarifio/.rvm/scripts/rvm
