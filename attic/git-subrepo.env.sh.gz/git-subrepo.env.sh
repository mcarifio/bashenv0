[[ -z "${GIT_SUBREPO_ROOT}" ]] && source_if_exists ~/src/gh/ingydotnet/git-subrepo/.rc
