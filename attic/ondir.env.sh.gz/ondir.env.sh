# broken
# (set -x; source_if_exists /usr/share/ondir/integration/$(basename ${SHELL}))
