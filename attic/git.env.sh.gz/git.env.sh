export curl_token=2e64358ae77059c24323611600a1dc5324af3946
function gitcurl {
    local url=${1:?'expecting a url'}
    \curl -O -u ${curl_token}:x-oauth-basic ${url}
}

# alias git=/opt/hub/current/bin/hub # front the git command, add more functionality

function gitapi {
    local suffix=${1:-'expecting an api entry'}
    local token=${2:-$(git config github.token)}
    curl -sS -H "Authorization: token ${token}" https://api.github.com${suffix}
}

# https://developer.github.com/v3/repos/#get
function git_repo_parent {
    # GET /repos/:owner/:repo
    local repo=${1:-'error'}
    local owner=${2:-$(git config github.user)}
    gitapi /repos/${owner}/${repo} | jq '.parent.git_url'
}
