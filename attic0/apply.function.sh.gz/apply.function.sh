# source this in

function apply {
  _f=$1; shift
  for i in $* ; do $_f $i ; done
}

function domain-check {
    local name=${1:?'expecting a name'}
    whois ${name} && gnome-open http://www.${name} &
}

# https://stackoverflow.com/questions/1203583/how-do-i-rename-a-bash-function
copy_function() {
  test -n "$(declare -f "$1")" || return 
  eval "${_/$1/$2}"
}

rename_function() {
  copy_function "$@" || return
  unset -f "$1"
}
